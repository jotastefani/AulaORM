package com.devsuperior.aulaorm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AulaormApplicationTests {

	@Test
	void contextLoads() {
	}

}
