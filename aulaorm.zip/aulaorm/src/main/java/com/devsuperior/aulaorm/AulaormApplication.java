package com.devsuperior.aulaorm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AulaormApplication {

	public static void main(String[] args) {
		SpringApplication.run(AulaormApplication.class, args);
	}

}
